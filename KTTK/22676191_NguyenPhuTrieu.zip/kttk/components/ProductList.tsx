import React from "react";
import { FlatList } from "react-native";
import ProductItem from "./ProductItem";
import { Product } from "../App";

type Props = {
  products: Product[];
  onAdd: (product: Product) => void;
};

const ProductList: React.FC<Props> = ({ products, onAdd }) => (
  <FlatList
    data={products}
    keyExtractor={item => item.id}
    renderItem={({ item }) => <ProductItem product={item} onAdd={onAdd} />}
  />
);

export default ProductList;