import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { Product } from "../App";

type Props = {
  product: Product;
  onAdd: (product: Product) => void;
};

const ProductItem: React.FC<Props> = ({ product, onAdd }) => (
  <View style={styles.item}>
    <Text style={styles.name}>Tên sản phẩm: {product.name}</Text>
    <Text style={styles.price}>Giá: {product.price} đ</Text>
    <Button title="Thêm vào giỏ" onPress={() => onAdd(product)} />
  </View>
);

const styles = StyleSheet.create({
  item: { backgroundColor: "#fff", padding: 16, marginBottom: 12, borderRadius: 8 },
  name: { fontSize: 18, fontWeight: "bold" },
  price: { fontSize: 16, color: "green", marginVertical: 8 }
});

export default ProductItem;