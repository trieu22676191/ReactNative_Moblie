import React, { useState } from "react";
import { SafeAreaView, StyleSheet } from "react-native";
import ProductList from "./components/ProductList";
import CartSummary from "./components/CartSummary";

export type Product = { id: string; name: string; price: number };

const PRODUCTS: Product[] = [
  { id: "1", name: "Áo đại bàng", price: 100000 },
  { id: "2", name: "Quần cá sấu", price: 100000 },
  { id: "3", name: "Nón sư tử", price: 100000 },
  { id: "4", name: "Dép da beo", price: 100000 },
];

export default function App() {
  const [cart, setCart] = useState<Product[]>([]);

  const addToCart = (product: Product) => {
    setCart([...cart, product]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <CartSummary cart={cart} />
      <ProductList products={PRODUCTS} onAdd={addToCart} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#f2f2f2" }
});